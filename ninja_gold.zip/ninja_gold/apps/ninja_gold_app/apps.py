from django.apps import AppConfig


class NinjaGoldAppConfig(AppConfig):
    name = 'ninja_gold_app'
